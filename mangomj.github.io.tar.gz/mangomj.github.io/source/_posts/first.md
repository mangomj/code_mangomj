---
title: 我的第一篇博客
---
>mango仓库blog开通，blog采用hexo+nodejs完成，基于开源更改，仅作为学习娱乐，若有侵权联系mj981022@163.com.

