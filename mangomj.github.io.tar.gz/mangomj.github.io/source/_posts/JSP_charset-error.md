---
title : Jsp页面传递数据中文乱码
categories : 编码乱码
---

>	在做一个web端的关于数据库操作的时候，要注意驱动文件版本问题以及数据库的登录名密码和数据库管理软件的tcp||ip启用，还有防火墙的关于1433端口法则配置允许，这些是最基本的能保证连上数据库的要求。在做jsp的一次实验的时候，我发现jsp页面的表单提交的中文数据出现了>乱码情况，在检查的时候发现，在jsp的文件前已经加上了<%@ page contentType="text/html;charset=UTF-8" language="java" %>,声明了字符编码，在servlet里也加上了request.setCharacterEncoding("utf-8")，但还是乱码。
>最后发现表单的method用的是get，但是request.setCharacterEncoding只对post有效，于是更改为post，就好了。
>
>
>
>
>
>