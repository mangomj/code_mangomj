---
title : Eclipse搭建Android开发环境
categories : Eclipse
---
>虽然google的android studio很香，但是有时候我们不得不使用eclipse进行android开发，那么怎么把android开发环境集成到eclipse上呢？
>下面给大家介绍一下eclipse搭建android开发环境的步骤
>1.安装jdk
>	当然如果你有eclipse肯定是安装了jdk的，不然没办法打开，去官网下载jdk8，JDK官网http://www.oracle.com/technetwork/java/javase/downloads/index.htm,然后进行安装，在cmd里输入java -version 查看java版本以去确定安装成功(jdk8之后不需要配置环境变量了)
>2.安装eclipse
>	Eclipse官网：http://www.eclipse.org/downloads/，下载安装
>3.安装Android SDK
>	去官网：http://developer.android.com/sdk/index.html下载,也可以下载集成了android环境的免安装eclipse，可以直接在具有java运行环境的计算机上运行
>4.Eclipse安装ADT插件
>	启动Eclipse，点击菜单Help -> Install New Software ...在弹出的菜单中，点击Add，输入名称，然后在URL中输入：http://dl-ssl.google.com/android/eclipse/ 之后点击Next，选择勾选ADT和NDK插件，选择安装即可，安装过程比较慢，需要耐心等待。
>按照提示一步一步安装完成后，会提示重启Eclipse。重启后如果发现Window菜单下没有出现AVD Manager菜单，则按照下面的方法操作：Window->Customize Perspective->Command Groups availability->Available command groups->勾选Android SDK and AVD Manager
>可以将Android相关的选项都勾选，这样Window菜单下就有Android SDK Manager和Android Virtual Device Manager菜单了。

>5.创建一个虚拟设备（虚拟机）
>点击Window->Android Virtual Device Manager，在弹出的对话框中删除系统默认的一个虚拟设备，然后点击New来添加，填写相关参数
>新增虚拟Android设备后，点击Start...启动Android虚拟机，启动过程非常慢

>6.创建一个Android项目
>File->New->Other，选择Android Application Project,根据提示创建即可，我创建的项目叫做AndroidTest，没有做任何修改，直接运行。

>7.运行Android项目

待虚拟机启动好后，再运行Android程序，运行Android程序方法：选中项目，点击菜单Run -> Run As -> 1 Adnroid Application，等待自动在虚拟机中运行

转自
--------------------- 
作者：海涛zht666 
来源：CSDN 
原文：https://blog.csdn.net/zht666/article/details/29837777 
