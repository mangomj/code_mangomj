---
title : 新版win10进pe蓝屏问题
categories: 启动盘||BIOS
---

>
笔者是一个装系统老手了，用的最多的就是u盘pe。但是有一次在给一个学弟装系统时发现用u启动和其他启动盘进pe，电脑
直接蓝屏，如下图所示
<img src="/imgs/wepe/erroe.jpg" width=500>
尝试多次也没办法，包括什么更改硬盘格式，但有的只有一种格式，根本没办法更改。
然后我尝试了<font color="red">wepe的win10pe系统</font>
进wepe官网下载wepe win10制作包
<img src="/imgs/wepe/wepe_download01.png" width=500>

然后安装，选择<font color="red">u盘制作</font>，如图所示

<img src="/imgs/wepe/wepe_download02.jpg" width=500>

选择制作的u盘和安装方式以及其他设置

<img src="/imgs/wepe/wepe_download03.jpg" width=500>

然后等安装

<img src="/imgs/wepe/wepe_download04.jpg" width=500>

完成

<img src="/imgs/wepe/wepe_download05.jpg" width=500>

插入u盘，重启电脑，长按esc或f12键进启动项，选择u盘，就ok了
罗列常见电脑型号对应的启动项键

<img src="/imgs/wepe/list.jpg" width=500>

