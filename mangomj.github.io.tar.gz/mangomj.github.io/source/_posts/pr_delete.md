
---
title: 关于pr安装失败
categories: PR
---
>在安装pr的时候总是有许多的问题，这很正常。
话不多说，首先拿到安装包后我们先断开网络连接，避免要登录adobe账号，再打开我的电脑，进c盘如图所示的文件目录下，删除里面的几个文件，
然后选好安装的位置，开始安装。然后就可以使用了。
<img src="https://ws1.sinaimg.cn/large/0072Lfvtly1g0z83egmj2j30tl0fu75l.jpg">
